package com.example.damiandurossweighttracker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private EditText phoneEditText;
    private Button saveButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Initializes views
        phoneEditText = findViewById(R.id.phoneEditText);
        saveButton = findViewById(R.id.saveButton);

        // Load and display saved phone number if exists
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String savedPhone = prefs.getString("phoneNumber", "");
        phoneEditText.setText(savedPhone);

        // Handle save button click
        saveButton.setOnClickListener(v -> {
            String phoneNumber = phoneEditText.getText().toString().trim();
            if (!phoneNumber.isEmpty()) {
                // Saves phone number to SharedPreferences
                prefs.edit().putString("phoneNumber", phoneNumber).apply();
                Toast.makeText(this, "Phone number saved", Toast.LENGTH_SHORT).show();
                finish(); // go back to DashboardActivity
            } else {
                Toast.makeText(this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
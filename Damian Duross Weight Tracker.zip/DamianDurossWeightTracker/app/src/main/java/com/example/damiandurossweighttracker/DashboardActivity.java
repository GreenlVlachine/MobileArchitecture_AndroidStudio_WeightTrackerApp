package com.example.damiandurossweighttracker;

import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.Manifest;
import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class DashboardActivity extends AppCompatActivity {

    // View
    FloatingActionButton fabEditGoal;
    TextView goalWeightTextView;

    // SMS Perm check
    private static final int REQUEST_SMS_PERMISSION = 101;
    public boolean isSmsPermissionGranted = false;

    // Database helper
    private WeightDatabaseHelper dbHelper;
    // RecylcerView for daily weight entries
    private RecyclerView recyclerView;
    private WeightLogAdapter adapter;
    private List<WeightLogEntry> weightLogEntries;
    private String username;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dashboard);

        // Gets username from intent and displays welcome message
        Intent intent = getIntent();
        this.username = intent.getStringExtra("USERNAME");
        TextView welcomeTextView = findViewById(R.id.welcomeMessageTextView);
        if (username != null && !username.isEmpty()) {
            welcomeTextView.setText("Welcome, " + username + "!");
        } else {
            welcomeTextView.setText("Welcome!");
        }

        // Check SMS Permissions and request if not granted
        isSmsPermissionGranted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        if (!isSmsPermissionGranted) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
        }

        // Initializes dbHelper and fetch table entries from db
        dbHelper = new WeightDatabaseHelper(this, username);
        Cursor cursor = dbHelper.getAllDailyWeights();
        weightLogEntries = convertCursorToList(cursor);

        // Initializes RecyclerView and adapter
        recyclerView = findViewById(R.id.weightRecyclerView);
        adapter = new WeightLogAdapter(weightLogEntries, username, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Adjust padding for Edge to Edge layout
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.dashboardLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Set up FAB for editing goal weight
        fabEditGoal = findViewById(R.id.fabEditGoal);
        fabEditGoal.setOnClickListener(v -> showEditGoalDialog());

        // Display current goal weight if set
        goalWeightTextView = findViewById(R.id.goalWeightTextView);
        String goalWeight = dbHelper.getGoalWeight();
        goalWeightTextView.setText("Goal Weight: " + (goalWeight != null ? goalWeight : "Not set"));
        if (goalWeight == null) {
            showEditGoalDialog();
        }

        // Set up FAB for daily weight entry
        findViewById(R.id.fabAddEntry).setOnClickListener(v -> showAddEntryDialog());

        // Button for SettingsActivity
        Button settingsButton = findViewById(R.id.settingsButton);
        settingsButton.setOnClickListener(v -> {
            Intent settingsIntent = new Intent(DashboardActivity.this, SettingsActivity.class);
            startActivity(settingsIntent);
        });
    }

    // Show dialog to add a new daily weight entry
    private void showAddEntryDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Daily Weight");

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        input.setHint("e.g. 175.0");
        builder.setView(input);

        builder.setPositiveButton("OK", (dialog, which) -> {
            String enteredWeight = input.getText().toString().trim();
            if (!enteredWeight.isEmpty()) {
                String weight = enteredWeight + " lbs";
                String today = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                long insertedId = dbHelper.insertDailyWeight(today, weight);
                if (insertedId != -1) {
                    WeightLogEntry newEntry = new WeightLogEntry(
                            (int) insertedId,
                            today,
                            weight
                    );
                    weightLogEntries.add(newEntry);
                    adapter.notifyItemInserted(weightLogEntries.size() - 1);
                    Toast.makeText(this, "Entry added", Toast.LENGTH_SHORT).show();

                    // Check if goal is reached and send SMS if applicable
                    String goalWeight = dbHelper.getGoalWeight();
                    if (goalWeight != null && !goalWeight.isEmpty() && isSmsPermissionGranted) {
                        checkAndSendSmsIfGoalReached(goalWeight);
                    }
                } else {
                    Toast.makeText(this, "Failed to add entry", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    // Method for checking if goal weight is reached and sending SMS notification
    public void checkAndSendSmsIfGoalReached(String weight) {
        try {
            float goal = Float.parseFloat(dbHelper.getGoalWeight());
            float latestWeight = Float.parseFloat(weight.replace(" lbs", "")); // Using the passed weight directly
            if (latestWeight <= goal) {
                sendSms("Congratulations! You've reached your goal weight of " + goal + " lbs.");
            }
        } catch (Exception e) {
            Log.e("SMS", "Error checking goal weight", e);
        }
    }

    // Method to send SMS message
    private void sendSms(String message) {
        SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);
        String phoneNumber = prefs.getString("phoneNumber", "");

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "No phone number set. Please update in Settings.", Toast.LENGTH_LONG).show();
            return;
        }

        int permissionCheck = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (permissionCheck != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "SMS Permission not granted", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, "SMS Sent", Toast.LENGTH_SHORT).show();

            createSmsNotification(message);
        } catch (Exception e) {
            Log.e("SMS", "Failed to send SMS", e);
            Toast.makeText(this, "SMS Sending Failed", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Re-check SMS permission in case user enabled it in system settings
        checkAndSetSmsPermission();
    }

    // Method to make sure SMS was sent in the event that SMS perms were declined, but later enabled in Settings
    private void checkAndSetSmsPermission() {
        boolean granted = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        // If you were using a flag like isSmsPermissionGranted, update it here
        isSmsPermissionGranted = granted;

        Log.d("Permissions", "SEND_SMS permission granted: " + granted);
    }

    // Method to create notifications after sending SMS (initially added for easier testing, it was a nice feature)
    private void createSmsNotification(String message) {
        String channelId = "sms_channel";
        String channelName = "SMS Notifications";

        // Create notification channel for Android O and above
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    channelId,
                    channelName,
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            if (notificationManager != null) {
                notificationManager.createNotificationChannel(channel);
            }
        }
        // Build and show notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_email) // You can replace or comment this out
                .setContentTitle("SMS Sent")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        // Check for notification perms before posting
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED) {
            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
            notificationManager.notify(1, builder.build());
        } else {
            Toast.makeText(this, "Notification permission not granted", Toast.LENGTH_SHORT).show();
        }
    }

    // Show dialog for editing goal weight
    private void showEditGoalDialog() {
        LayoutInflater inflater = LayoutInflater.from(this);
        View dialogView = inflater.inflate(R.layout.dialog_edit_goal_weight, null);
        EditText input = dialogView.findViewById(R.id.editGoalWeightInput);

        new AlertDialog.Builder(this)
                .setTitle("Edit Goal Weight")
                .setView(dialogView)
                .setPositiveButton("Save", (dialog, which) -> {
                    String newWeightStr = input.getText().toString().trim();
                    if(!newWeightStr.isEmpty()) {
                        float newWeight = Float.parseFloat(newWeightStr);
                        dbHelper.updateGoalWeight(newWeight);
                        goalWeightTextView.setText("Goal Weight: " + newWeight + " lbs");

                        // Checks if new goal weight is reached
                        if (!weightLogEntries.isEmpty() && isSmsPermissionGranted) {
                            checkAndSendSmsIfGoalReached(String.valueOf(newWeight));
                        }
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SMS_PERMISSION) {
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permissions Granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS Permissions Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Convert Cursor to list of weight entries
    private List<WeightLogEntry> convertCursorToList(Cursor cursor) {
        List<WeightLogEntry> entries = new ArrayList<>();
        if (cursor != null && cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("daily_id"));
                String date = cursor.getString(cursor.getColumnIndexOrThrow("daily_date"));
                String weight = cursor.getString(cursor.getColumnIndexOrThrow("daily_weight"));
                entries.add(new WeightLogEntry(id, date, weight));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return entries;
    }
}
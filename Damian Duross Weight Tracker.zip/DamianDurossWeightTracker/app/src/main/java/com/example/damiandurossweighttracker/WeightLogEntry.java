package com.example.damiandurossweighttracker;

public class WeightLogEntry {
    private int id;
    private String date;
    private String weight;

    //Constructor
    public WeightLogEntry(int id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    //Getters
    public int getId() {
        return id;
    }

    public String getDate() {
        return date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }
}
